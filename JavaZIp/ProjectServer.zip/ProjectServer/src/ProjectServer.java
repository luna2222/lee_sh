import java.io.BufferedReader;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;
import java.util.*;


public class ProjectServer {
	ServerSocket serverSocket = null;
	Socket socket = null;
	Map<String, PrintWriter> clientMap;
	Map<String, String> roomMap;
	String UserName=null;
	
	Connection con =null;     //오라클 데이터 베이스	
	Statement stmt=null;
	ResultSet rs =null;
	String sql=null;
	
	static { //오라클 접속
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
		System.out.println("데이터 베이스가 연결합니다.");
	}
	

	//생성자
	public ProjectServer() {
	 //클라이언트의 출력스트림을 저장할 해쉬맵 생성
		clientMap =new HashMap<String,PrintWriter>();
		
		//해쉬맵의 동기화 설정
		Collections.synchronizedMap(clientMap);
		
  }
	public  void init()
	{
		try {
		serverSocket =new ServerSocket(9999);
		System.out.println("서버가 시작되었습니다.");
					
		while(true) {
			socket = serverSocket.accept();
			System.out.println(socket.getInetAddress()+":"+socket.getPort());
			
			Thread msr=new MultiServerT(socket);//쓰레드 생성
			msr.start();//쓰레드 시동
		   }
		
			}catch(Exception e) {
		      e.printStackTrace();
			}finally {
				try {
					serverSocket.close();
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
	}
	
	public void list(PrintWriter out)      //접속자 리스트 보내기
	
	{	
//		List<String> chatUserList =new ArrayList<String>();
		//출력스트림을 순차적으로 얻어와서 해당 메세지를 출력
		Iterator<String> it =clientMap.keySet().iterator();
		String msg ="사용자 리스트 [";
		while (it.hasNext()) {
			msg+=(String)it .next() +",";
		}
		msg =msg.substring(0,msg.length()-1)+"]";
		out.println(msg);
	   }
	  
	  //접속된 모든 클라이언트들에게 메세지를 전달=방에 입장하지 않은 유저에게만
	public void sendAllMsg(String id, String msg) 
		{
			//출력스트림을 순차적으로 얻어와서 해당메세지를 출력
			Iterator<String> it =clientMap.keySet().iterator();
			
			while(it.hasNext()) {
			try {
				PrintWriter it_out = (PrintWriter) clientMap.get(it.next());
				if(UserName.equals(""))
				   it_out.println(msg);
				else
					it_out.println("[" + UserName + "] " + msg);
			} catch (Exception e) {
				System.out.println("예외:" + e);
			}
		}
	}
	// 귓속말 상대 값 저장
		public String wUser(String s, PrintWriter out) { 
			
			String UserName = null;
			Iterator<String> it = clientMap.keySet().iterator();
			if (String.valueOf(s.substring(0, 2)).equals("/t")&&(s.substring(0, 3)).equals("/to")) {
				while (it.hasNext()) {
					String tmp = it.next();
					try {
						if (String.valueOf(s.substring(4, (4 + tmp.length()))).equals(tmp)) {
							UserName = tmp;
							return UserName;
						}					
						
					}catch (Exception e) { 
						e.printStackTrace();
					}
				}
				return UserName;
			}
			return UserName;
		}
	public void whisperMsg (String name, String userName, String s, PrintWriter out) {
		out.println("[귓속말 나]: " + s);
		out = clientMap.get(userName); // 보낼 상대방 지정
		out.println("[귓속말 "+name+"님]: " + s);
		
		
	}
	public static void main(String[] args) {
		
		 ProjectServer ms =new  ProjectServer();
		ms.init();
	}
	///////////////////////////////////////////////////////////////
	//내부 클래스  클라이언트로부터 읽어온 메세지를 
	//다른	클라이언트에 보내는 역할 메서드
			class MultiServerT extends Thread
			{
				Socket socket = null;
				PrintWriter out = null;
				BufferedReader in = null;
	            
				public  MultiServerT(Socket socket)	{ //생성자
					this.socket=socket;
					try {
					    out = new PrintWriter(this.socket.getOutputStream(), true);
						in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
					} catch(Exception e){
							System.out.println("예외:" + e);
					}
				}
			//쓰레드를 사용하기위해서 run()	메서드를 재정의
			@Override
			public void run() {
				//String s = "";
				String id = null;
				String name = ""; //클라이언트로부터 받은 이름을 저장할 변수
				String UserName = null; // 귓속말 고정 세팅
				String title = null; // 채팅방 고정 세팅  채팅방 닉네임 체크 있을 경우 not null 	
				try {
					id=in.readLine();//클라이언트에서 처음으로 보내는 메세지는 
						               //클라이언트가 사용할 이름이다
					name=getName();
					sendAllMsg("",name +"님이 입장하였습니다.");
					//현재 객쳬가 가지고있는 소켓을 제외하고 다른 소켓(클라이언트)들에게 접속을 알림 
					clientMap.put(name,out);//해쉬맵애 키를 name으로 출력스트림 객체를 저장
					System.out.println("현재접속자 수는 "+clientMap.size()+"명 입니다.");
						
						//입력스트림이 null이 아니면 반복
						String s="";
						while (in != null) {
							 s = in.readLine();
							 System.out.println(s);
					//		 title = ckRoom(id, out);
								
 						//	if (s.substring(0, 1).equals("/")||s.substring(0, 1).equals("|")) {
						//	 user=wUser(s,out);
						// }
//   			             if (s.equals("q") || s.equals("Q"))
//				              break;
							 if(s.equals("/list"))
								 list(out);
							 else if (s.substring(0, 3).equals("/to")) {
								 UserName=wUser(s,out);
								 whisperMsg(name, UserName, s, out);
							 }
								 
							 else if(UserName!= null)  //귓속말 고정
								
							 
							     // 대기실 대화
									//System.out.println("대기실 대화");
								 if(UserName!=null)
									 whisperMsg(name, UserName, s, out);
								 else
 
									sendAllMsg(id, s);
							 							 							
					}
				//		System.out.println("bye...");

					} catch (Exception e) {
						System.out.println("예외:" + e);
					} finally {
						//예외가 발생할때 퇴장. 해쉬맵에서 해당 데이터 제거
						//보통 종료하거나 나가면 java.net.SocketException: 발생
						clientMap.remove(id);
						sendAllMsg("",id+ "님이 퇴장");
						System.out.println("현재 접속자수는 "+clientMap.size()+"명입니다");
						try {
							in.close();
							out.close();
							socket.close();

						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
		   }
	//////////////////////////////////////////////////////
		}	
