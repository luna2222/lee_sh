import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProjectClient
{	
	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
	}
	public static void main(String[] args) throws Exception, UnknownHostException, IOException
	{
		while(true)
		{
			Scanner sc = new Scanner(System.in);
			
			System.out.println("선택하세요.");
			System.out.println();
			System.out.println("1. 회원 가입");
			System.out.println("2. 로그인");
			System.out.println("3. 계정 삭제");
			System.out.println("4.프로그램 종료");
			System.out.println("선택 :");
			int num = sc.nextInt();
		   
			
			
			if(num==1)	//////회원가입
			{	
				Scanner s1 = new Scanner(System.in);					
				Connection con = null;
				Statement stmt = null;		
				ResultSet rs = null;
				String id;
				String password;
				String name;
				
				try {
					con = DriverManager.getConnection(
							  "jdbc:oracle:thin:@localhost:1521:xe",
							  "scott",
							  "tiger");
					stmt = con.createStatement();
					
					System.out.println("아이디을 입력하세요.");
					name = s1.next();
										
					System.out.println("이름를 입력하세요.");			
					id = s1.next();
					
					System.out.println("비밀번호를 입력하세요.");
					password = s1.next();

					//-----------------------------------------------
					String sql = "select * from ProChat where id = '"+id+"'";
					System.out.println(sql);
					//->  제대로 출력되는지 확인용
					
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						System.out.println("중복된 아이디입니다. \n다시 입력해 주세요. \n");
					} else {
						System.out.println("가입되셨습니다. \n");
						// 인서트
						String sql2 = "insert into ProChat     " +
									  "values ('"+id+"','"+name+"', '"+password+"')";
						int updateCount = stmt.executeUpdate(sql2);
					}
					
					//-----------------------------------------------
					rs.close();
					stmt.close();
					con.close();
					
				} catch (SQLException sqle) {
					System.out.println("Connection Error");
					sqle.printStackTrace();
				}
				
				
			}
						
	/////로그인 하기
		
			if(num==2)
			{
				Scanner s2 = new Scanner(System.in);
				String id;
				String name=null;
				String password;
				String UserID;
				String UserName;
				String pwd;
				System.out.println("로그인");
				System.out.println("");
				System.out.println("ID : ");
				id = s2.next();
				System.out.println("비밀번호 : ");
				password = s2.next();
				System.out.println("로그인을 시작합니다.");		
				try 
				{
					Connection con = DriverManager.getConnection(
							"jdbc:oracle:thin:@localhost:1521:xe",
							"scott",
							"tiger");
					
					String sql = "select * from Prochat where ID = "+"'" +id+ "'";
					PreparedStatement pstmt = con.prepareStatement(sql);				
					ResultSet rs = pstmt.executeQuery();
					
					if(rs.next())
					{   
						UserID = rs.getString(1);
						UserName= rs.getString(2);				
						pwd = rs.getString(3);
					
					
						if(UserID.equals(id) && pwd.equals(password)) 
						{
							System.out.println("로그인 되었습니다");
                    ////// [ 로그인 -> 자동서버접속 ] ///////				
							try {
								String ServerIP = "localhost";
								if(args.length>0)
									ServerIP = args[0];
								Socket socket = new Socket(ServerIP, 9999);
								System.out.println("서버와 연결되었습니다.");
								
								Thread receiver = new ProReceiver(socket);
								receiver.start();
								
								new ChatWin(socket,name);
								
							} catch (Exception e) {
								System.out.println("서버와 연결해주세요.");
							}
								break;
///////////////////////////////////////////////////////////////////////																				
						} else {
							System.out.println("정보가 틀렸습니다.");
							System.out.println("다시 입력해주세요.");
							System.out.println();
							continue;
						}
						
					}					
			
					if(id.equals("")) {
					System.out.println("아이디가 없습니다.");
					System.out.println("다시 입력해주세요.");
					continue;
					}
							
					rs.close();
					pstmt.close();
					con.close();
					break;												
				} 
				catch (Exception e) {
						e.printStackTrace();
						continue;													
				}							
			}
			
			if(num==3)  ////계정삭제=>회원탈퇴 
			{
				Scanner s3 = new Scanner(System.in);
				
				String id;
				String name;
				String password;
				
				String UserID;
				String UserName;
				String pwd;
				
				System.out.println("탈퇴하시겠습니까");
				
				System.out.println("ID : ");
				id = s3.next();
				System.out.println("이름 : ");
				name = s3.next();
				System.out.println("PASSWARD : ");
				password= s3.next();
				System.out.println("계정삭제를 진행하겠습니다.");
				System.out.println();
			    			
			try 
			{
				Connection con = DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:xe",
						"scott",
						"tiger");
				
				Statement stmt = con.createStatement();			
				StringBuffer sb = new StringBuffer();
				
				String sql = "select * from ProChat where id = '"+id+"'";
				PreparedStatement pstmt = con.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();
				
				if(rs.next())
				{
					UserName = rs.getString(1);
					UserID = rs.getString(2);
					pwd = rs.getString(3);
				
					if(name.equals(UserName)&& id.equals(UserID) && password.equals(pwd)) 
					//if(UserName.equals(name) && UserID.equals(id) && pwd.equals(password)) 
					{
						sql = "delete from  ProChat where ID = '"+id+"'";
						pstmt = con.prepareStatement(sql);
						rs = pstmt.executeQuery();
						sb.setLength(0);
						
						System.out.println("계정이 삭제되었습니다.");
						System.out.println();
						continue;
						
				
					} else {
						System.out.println("정보가 일치하지않습니다.");
						System.out.println("다시 입력해주세요.");
						System.out.println();
						continue;
					}
				}
				
				pstmt.close();
				stmt.close();
				con.close();
				System.out.println("삭제가 완료되었습니다!");
				System.out.println("");	
				
			} catch(Exception e) {
				System.out.println("삭제를 실패했습니다.");
				System.out.println();
				continue;				
			}
		}
						
///////////////////////////////////////////////////////////			
			if(num==4)
			{
				System.out.println("프로그램을 종료합니다.");
				System.out.println();
				return;
			}
			
		
		}
	}
}