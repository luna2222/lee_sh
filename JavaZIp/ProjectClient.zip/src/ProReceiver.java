import java.io.*;
import java.net.Socket;
import java.*;
//서버에서 오는 내용을 받는 역할만 함
//서버에서 메세지를 전송하는 클래스
public class ProReceiver extends Thread {
	Socket socket;
	BufferedReader in= null;
	
	//Socket을 매개변수로 받는 생성자
	public ProReceiver(Socket socket)
	{
		this.socket=socket;
		try {
			in= new BufferedReader(new InputStreamReader(
					this.socket.getInputStream()));
			
				}catch(Exception e) {
			System.out.println("예외s3:"+e);
		}		
	}
	//run() 메소드 재정의
	@Override
	public void run() {
		while (in !=null) {
			try {
			 System.out.println(">>"+in.readLine());
			 //서버에 입력한 사용자 이름을 보내준다
		}catch (java.net.SocketException ne) {
			 break;
		} catch(Exception e) {
			System.out.println("예외 : "+e);
		   }
	   }
			
		try {
			in.close();
			} catch(Exception e) {
			System.out.println("예외s2:"+e);
		}
	}
}